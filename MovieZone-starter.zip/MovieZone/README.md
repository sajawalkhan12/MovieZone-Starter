# MovieZone — Android-friendly starter prototype

This is a first working browser prototype for the MovieZone project.

## What it currently does
- English / Urdu text toggle
- Movie and video-song library cards
- Search and category filtering
- Add categories and remove categories
- Add a title, poster, video file, and optional separate audio file
- HTML video player
- Download the selected video or its separately supplied audio file

## Important limitations
- This is a local browser demo, not a production streaming service.
- Added media uses temporary browser object URLs; it is not uploaded to a server and may disappear after refresh or browser cleanup.
- Admin controls are not secured by a server login.
- MP3 extraction/conversion is not implemented. Supply a separate audio file that you own or are licensed to distribute.
- 4K/UHD playback depends on the device/browser and the source file; uploading 4K requires suitable hosting, storage, bandwidth, and rights.
- Do not upload copyrighted movies or songs without permission.

## Run on Android
Open `index.html` from a code editor preview or publish the project using a static website host. For a real multi-user app, add authenticated admin access and a media-storage backend before publishing.

## Files
- `index.html`: single-file starter app
